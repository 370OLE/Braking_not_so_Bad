using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

// This class is connected to the "Global" Scene and updates the visable information during the game
public class UI_Manager : MonoBehaviour
{
    [SerializeField]
    private Text _livestext;

    [SerializeField]
    private Text _scoretext;

    [SerializeField]
    private Text _leveltext;

    // a function to print out the lives 
    public void UpdateLives(int health)
    {
        // we have a cap of four lives, so we do not have to check for more.
        if (health == 3) {
            _livestext.text = "\u2665  \u2665  \u2665"; // here are three hearts, they will be visualised correctly
        } else if (health == 2) {
            _livestext.text = "\u2665  \u2665";
        } else if (health == 1) {
            _livestext.text = "\u2665";
        } else if (health == 4) {
            _livestext.text = "\u2665  \u2665  \u2665  \u2665";
        } else {
            // this will never happen... unless you are cheating ;)
            _livestext.text = "What?";
        }
    }

    // a function to print out the score 
    public void UpdateScore(int score)
    {
        _scoretext.text = "Score: " + score;
    }

    // a function to print out the level 
    public void UpdateLevel(int level)
    {
        _leveltext.text = "Level: " + level;
    }
}