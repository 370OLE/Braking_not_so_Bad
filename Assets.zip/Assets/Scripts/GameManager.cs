using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections;
using System.Collections.Generic;

// The GameManager is the most important piece in our code
// It ceaps track of the lives, score, level and loads the scenes.
// It also calls the other scripts and initializes movement.
public class GameManager : MonoBehaviour
{
    public Ball ball { get; private set; }
    public Paddle paddle { get; private set; }
    public Brick[] bricks { get; private set; }

    // The "UI_Manager" updates the canvas, so we need to give it information about score, level and lives
    [SerializeField]
    private UI_Manager _uiManager;

    // there are 5 levels in total and the 6th one is the Winning-Screan
    const int NUM_LEVELS = 6;

    // we define the level, score and lives at the start, so we can interact with it during the game.
    public int level = 1;
    public int score = 0;
    public int lives = 2;

    private void Awake()
    {
        // we want to ceep an eye on the lives and so on, so we tell the programm to persist further on 
        DontDestroyOnLoad(gameObject);
        DontDestroyOnLoad(_uiManager);
        // DontDestroyOnLoad(GameOverScreen);

        // load everything when we enter a new level
        SceneManager.sceneLoaded += OnLevelLoaded;
    }

    // let's start the game at the beginning...
    private void Start()
    {
        NewGame();
    }

    // the function resets the Intiger and loads the first level
    public void NewGame()
    {
        // reset stats for the first level
        score = 0;
        lives = 2;
        _uiManager.UpdateScore(0);

        // and start
        LoadLevel(1);
    }

    // a function that loads the wanted level
    private void LoadLevel(int level)
    {
        this.level = level;
        // then we update the lives and level 
        _uiManager.UpdateLives(lives);
        _uiManager.UpdateLevel(level);

        // loads the scene for the respective level
        SceneManager.LoadScene("Level" + level);
    }

    // when we load a new level, we want to update the paddle, ball and bricks.
    private void OnLevelLoaded(Scene scene, LoadSceneMode mode)
    {
        ball = FindObjectOfType<Ball>();
        paddle = FindObjectOfType<Paddle>();
        bricks = FindObjectsOfType<Brick>();

        // you gain a extra live for each level
        if (lives < 4) {
            lives++;
            _uiManager.UpdateLives(lives);
        }

    }

    // a function to update and ceep track of the lives
    public void Miss()
    {
        // on a miss, decrease the live
        lives--;
        _uiManager.UpdateLives(lives);

        // if we still have lives, reset the positions. If not, the player is game over.
        if (lives > 0) {
            ResetLevel();
        } else {
            GameOver();
        }
    }

    // a function to reset a level
    public void ResetLevel()
    {
        paddle.ResetPaddle();
        ball.ResetBall();
    }

    // hehehe you loose 
    private void GameOver()
    {
        // Start a new game immediately
        NewGame();
    }

    // ceeps an eye on the score and loads the next level, if we have cleared the board
    public void Hit(Brick brick)
    {
        score += brick.points;
        _uiManager.UpdateScore(score);

        // if we have cleared the board, advance to the next level
        if (Cleared()) {
            LoadLevel(level + 1);
        }
    }

    // a function to check if we have cleared the board
    private bool Cleared()
    {
        // go through every brick
        for (int i = 0; i < bricks.Length; i++)
        {
            // if there are any breakable bricks, we are not done yet
            if (bricks[i].gameObject.activeInHierarchy && !bricks[i].unbreakable) {
                return false;
            }
        }

        // if there are no breakable or just unbreakable, we return true
        return true;
    }

}
