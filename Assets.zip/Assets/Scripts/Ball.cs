using UnityEngine;

// calculates and sets the dierection of the ball
[RequireComponent(typeof(Rigidbody2D))]
public class Ball : MonoBehaviour
{
    // initiate Rigidbody and speed
    public new Rigidbody2D rigidbody { get; private set; }
    public float speed = 10f;

    // at first, find the ball
    private void Awake()
    {
        rigidbody = GetComponent<Rigidbody2D>();
    }

    // reset the ball at the beginning
    private void Start()
    {
        ResetBall();
    }

    // a function to reset the ball at the start of a level
    public void ResetBall()
    {
        rigidbody.velocity = Vector2.zero;
        transform.position = Vector2.zero;

        // provides a delay of one second for the player to ready
        Invoke(nameof(SetRandomTrajectory), 2f);
    }

    // this function sets the direction of the ball
    private void SetRandomTrajectory()
    {
        // shoots the ball in random direction at the beginning of each round
        Vector2 force = new Vector2();
        force.x = Random.Range(-0.75f, 0.75f);
        force.y = -1f;

        // add to Rigidbody
        rigidbody.AddForce(force.normalized * speed);
    }

    // a function to update the movement of the ball
    private void FixedUpdate()
    {
        rigidbody.velocity = rigidbody.velocity.normalized * speed;
    }

}
