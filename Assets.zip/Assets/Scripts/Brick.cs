using UnityEngine;

// this class updates the bricks and checks if the player has cleared the level.
[RequireComponent(typeof(BoxCollider2D))]
public class Brick : MonoBehaviour
{
    public SpriteRenderer spriteRenderer { get; private set; }
    public Sprite[] states = new Sprite[0];
    public int health { get; private set; }
    public int points = 100;
    public bool unbreakable;

    private void Awake()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
    }

    private void Start()
    {
        ResetBrick();
    }

    // a function to reset the bricks at the start of a level
    public void ResetBrick()
    {
        gameObject.SetActive(true);

        // there are unbreakable objekts, so we check this first.
        if (!unbreakable) {
            // define the health of the brick by the states leangth.
            health = states.Length;
            spriteRenderer.sprite = states[health - 1];
        }
    }

    // here is what happens, when the ball hits a brick
    private void Hit()
    {
        // if the brick is unbreakable, do nothing
        if (unbreakable) {
            return;
        }

        // else reduce the life of the brick
        health--;

        // if the health is by 0 delete the element, else change the appearance
        if (health <= 0) {
            gameObject.SetActive(false);
        } else {
            spriteRenderer.sprite = states[health - 1];
        }

        // this calls the "GameManager" to check, if the board is cleared and to increase the score
        FindObjectOfType<GameManager>().Hit(this);
    }

    // we wanted to implement items. That is why we check, if the coliding object is the ball.
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.name == "Ball") {
            Hit();
        }
    }

}
