using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

// The class is only used from the Winning-Screan (Level6) to start all over
public class OnWin : MonoBehaviour
{
    // calls the "GameManager", which resets the score, live and level and loads the first level again.
    public void PlayAgain() 
    {
        FindObjectOfType<GameManager>().NewGame();
    }
}
