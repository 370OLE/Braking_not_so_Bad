using UnityEngine;

// This class checks the player input and sets the movement of the paddle.
[RequireComponent(typeof(Rigidbody2D))]
public class Paddle : MonoBehaviour
{
    public new Rigidbody2D rigidbody { get; private set; }
    public Vector2 direction { get; private set; }
    public float speed = 30f;
    public float maxBounceAngle = 75f; // the ball will never bounce in a higher angle than 75 persent

    private void Awake()
    {
        rigidbody = GetComponent<Rigidbody2D>();
    }

    private void Start()
    {
        ResetPaddle();
    }

    // A function that resets the paddle at the beginning of a level
    public void ResetPaddle()
    {
        rigidbody.velocity = Vector2.zero;
        transform.position = new Vector2(0f, transform.position.y);
    }

    // a function to get the players input and calculate the direction
    private void Update()
    {
        // the player can either use A/D buttons or <-/-> to move the paddle
        if (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow)) {
            direction = Vector2.left;
        } else if (Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow)) {
            direction = Vector2.right;
        } else {
            direction = Vector2.zero;
        }
    }

    // here happens the actual movement
    private void FixedUpdate()
    {
        // if there is a direction, than move!
        if (direction != Vector2.zero) {
            rigidbody.AddForce(direction * speed);
        }
    }

    // a function to controule the balls direction with the paddle
    // the incomming angle and the position of the ball on the paddle are important
    private void OnCollisionEnter2D(Collision2D collision)
    {
        // we get the position of the ball to calculate the new angle
        Ball ball = collision.gameObject.GetComponent<Ball>();

        // when the ball first colides with the paddle:
        if (ball != null){
            // where does the ball hit the paddle
            Vector2 paddlePosition = transform.position;
            Vector2 contactPoint = collision.GetContact(0).point;

            // calculate how far the contactpoint is off set of the paddle middle position, than calculate the persantige of the offset
            float offset = paddlePosition.x - contactPoint.x;
            float maxOffset = collision.otherCollider.bounds.size.x / 2; // we devide here by two because we want 100% on the left and right side of the paddle

            // at wich angle does the ball hit the paddle? 
            // calculate the bouncangle with the offset position of the paddle, than calculate the new direction where the ball will go to
            float currentAngle = Vector2.SignedAngle(Vector2.up, ball.rigidbody.velocity);
            float bounceAngle = (offset / maxOffset) * maxBounceAngle;
            float newAngle = Mathf.Clamp(currentAngle + bounceAngle, -maxBounceAngle, maxBounceAngle);

            // update the new direction
            Quaternion rotation = Quaternion.AngleAxis(newAngle, Vector3.forward);
            ball.rigidbody.velocity = rotation * Vector2.up * ball.rigidbody.velocity.magnitude;
        }
    }

}
