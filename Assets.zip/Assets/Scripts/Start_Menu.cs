using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

// This class has simply the purpose to load the "Global" scene, wich is connected to every game important scripts 
public class Start_Menu : MonoBehaviour
{

    public void Button() 
    {
        SceneManager.LoadScene("Global");
    }

}
