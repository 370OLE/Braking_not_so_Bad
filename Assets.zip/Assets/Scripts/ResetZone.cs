using UnityEngine;

// this class is connected to the "Wall" down below to inform the "GameManager" about the miss
[RequireComponent(typeof(Collider2D))]
public class ResetZone : MonoBehaviour
{

    // If we miss the ball reset the zone and inform the GameManager
    private void OnTriggerEnter2D(Collider2D other)
    {
        FindObjectOfType<GameManager>().Miss();
    }

}